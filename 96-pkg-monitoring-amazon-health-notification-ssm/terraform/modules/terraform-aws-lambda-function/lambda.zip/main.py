import os
import json
import requests
import boto3

from typing import Optional
from slack_sdk import WebClient

ssm_client = boto3.client("ssm")
slack_api_token_ssm_key = os.getenv("SLACK_API_TOKEN_SECRET_PATH")
environment = os.getenv("ENVIRONMENT")
slack_client: Optional[WebClient] = None

def lambda_handler(event, context):
   
    slack_token = ""
    try:
        response = ssm_client.get_parameter(
            Name=slack_api_token_ssm_key, WithDecryption=True
        )
        slack_token = response["Parameter"]["Value"]
    except:
        raise

    slack_client = WebClient(token=slack_token)
    
    # Define the message you want to send to Slack
    message = {
        "text": "EventBridge event triggered: " + json.dumps(event)
    }

    try:
        response = requests.post(
            slack_token,
            data=json.dumps(message),
            headers={'Content-Type': 'application/json'}
        )

        if response.status_code == 200:
            print("Message sent to Slack successfully")
        else:
            print("Failed to send message to Slack")
            print("Response:", response.text)

    except Exception as e:
        print("Error:", str(e))

    return {
        'statusCode': 200,
        'body': json.dumps('Message sent to Slack')
    }

